Cognitive Modeling - CGSC 4601 - Final Project
Saurabh Gummaraj Kishore
101163778

The following folder contains: 
	final.py
	README.txt

Additional instructions:
	
	1. Download python-act.
	2. Please make sure you are running the final.py inside the python-actr-main folder.


NOTE:

For this final project I chose to create a GOMS model of a Tim Hortons store with 4 appliances and a few food choices that the human aged could interact with. I had a lot of building this, I chose to try and resemble the initial GOMS model for simplicity however I did add a few additional appliances and objects within the environment along with a few extra actions int action module. 

I originally was hoping to add a few Declarative memory features such as forgetting and manipulating spreading activation for the human agent, but when I tried to do so it kept breaking my program. 

I would love to sit down one day and have coffee with you and learn more about some of the practical uses and challenges of cognitive modeling and talk about the future of this field. 

I really loved this course and  I was surprised to see that the learning theory of mastery that you mentioned at the very beginning of class actually really worked! Thank you for teaching us and hope you have an awesome summer! 

Regards,
Saurabh Kishore